#!/bin/sh

nohup {{abs_path}}/nginx-prometheus-exporter -nginx.scrape-uri http://{{instance_server}}:{{instance_port}}/stub_status -web.listen-address=":{{port}}" > data/app.log 2>&1 &
