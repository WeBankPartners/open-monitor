#!/bin/sh

nohup {{abs_path}}/redis_exporter --redis.addr="redis://{{instance_server}}:{{instance_port}}" --redis.password="{{auth_password}}" --web.listen-address=":{{port}}" > data/app.log 2>&1 &
