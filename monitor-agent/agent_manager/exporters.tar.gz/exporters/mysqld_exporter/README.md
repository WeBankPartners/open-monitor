#create user exporter
CREATE USER 'exporter'@'localhost' IDENTIFIED BY 'prom_pwd';
GRANT PROCESS, REPLICATION CLIENT, SELECT ON *.* TO 'exporter'@'localhost';
flush privileges;

#start
./mysqld_exporter --config.my-cnf="my.cnf"
